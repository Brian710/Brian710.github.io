
let RunRight = document.getElementById("RunRight");
anime({
    targets: RunRight,
    translateX: 250,
    duration: 10000
});